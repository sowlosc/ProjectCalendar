#include "observateur.h"


